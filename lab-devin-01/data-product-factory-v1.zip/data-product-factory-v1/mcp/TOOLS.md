# MCP Tools Contract

## validate_data_product
Input:
{ "definition": "<yaml ou markdown>" }

Retorna:
- valid
- errors
- warnings
- architecture

## generate_data_product
Input:
{ "definition": "<yaml ou markdown>", "output_path": "<path>" }

Retorna:
- generated artifacts
- selected architecture
- validation status
- deployment.executed=false

## validate_terraform
Input:
{ "path": "<terraform path>", "run_plan": false }

Executa somente fmt/validate e opcionalmente plan.

## explain_architecture
Input:
{ "definition": "<yaml ou markdown>" }

Retorna a justificativa da arquitetura escolhida.

O MCP NÃO deve expor shell genérico ao agente.
