# Security Policy
- S3 privado
- encryption habilitada
- public access bloqueado
- IAM least privilege
- tags obrigatórias
- nenhum secret hard-coded
