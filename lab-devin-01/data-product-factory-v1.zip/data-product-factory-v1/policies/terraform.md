# Terraform Policy
Allowed: fmt, validate, plan.
Forbidden: apply, destroy, import.
Deployment é responsabilidade do CI/CD após aprovação.
