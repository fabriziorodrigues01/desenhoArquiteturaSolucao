# Naming Policy
Data Product: lowercase kebab-case.
Buckets e recursos devem incorporar product + environment + layer quando aplicável.
