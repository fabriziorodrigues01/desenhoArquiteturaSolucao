def main():
    print("SOR Glue job: {{product_name}}")
    print("TEMP: s3://{{temp_bucket}}/")
    print("SOR: s3://{{sor_bucket}}/")

if __name__ == "__main__":
    main()
