resource "aws_glue_catalog_database" "sor" {
  name = "{{product_name}}_sor"
}

resource "aws_glue_catalog_table" "sor" {
  name = "{{sor_table}}"
  database_name = aws_glue_catalog_database.sor.name

  storage_descriptor {
    location = "s3://${aws_s3_bucket.sor.bucket}/sor/"
    input_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"

    ser_de_info {
      serialization_library = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe"
    }
  }
}
