resource "aws_glue_job" "sor" {
  name = "{{product_name}}-sor"
  role_arn = aws_iam_role.glue.arn

  command {
    script_location = "s3://${aws_s3_bucket.sor.bucket}/jobs/sor_job.py"
    python_version = "3"
  }

  glue_version = "5.0"
  worker_type = "G.1X"
  number_of_workers = 2
}
