def main():
    print("SPEC Glue job: {{product_name}}")
    # Business/regulatory/domain rules are injected here.

if __name__ == "__main__":
    main()
