def main():
    print("SOT Glue job: {{product_name}}")
    # Business transformation generated from the Data Product definition.

if __name__ == "__main__":
    main()
