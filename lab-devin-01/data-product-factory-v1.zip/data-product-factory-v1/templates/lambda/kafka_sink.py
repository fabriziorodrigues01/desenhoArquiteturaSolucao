import json

def handler(event, context):
    # V1 scaffold. Production implementation must add the selected Kafka
    # integration, schema/serialization handling and idempotency.
    return {
        "statusCode": 200,
        "body": json.dumps({
            "data_product": "{{product_name}}",
            "target": "s3://{{temp_bucket}}/"
        })
    }
