resource "aws_iam_role" "step_functions" {
  name = "{{product_name}}-sfn-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = { Service = "states.amazonaws.com" }
      Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_sfn_state_machine" "spec" {
  name = "{{product_name}}-spec"
  role_arn = aws_iam_role.step_functions.arn
  definition = file("${path.module}/../step-functions/spec_workflow.json")
}
