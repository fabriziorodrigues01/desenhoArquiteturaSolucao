locals {
  common_tags = {
    DataProduct = "{{product_name}}"
    Domain      = "{{domain}}"
    Environment = var.environment
    ManagedBy   = "data-product-factory"
  }
}
