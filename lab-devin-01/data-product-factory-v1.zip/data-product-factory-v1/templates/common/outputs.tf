output "data_product_name" {
  value = "{{product_name}}"
}
