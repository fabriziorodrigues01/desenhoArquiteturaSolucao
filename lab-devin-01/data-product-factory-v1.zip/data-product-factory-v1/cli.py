#!/usr/bin/env python3
import argparse, json
from pathlib import Path
from src.service import parse, architecture, generate, validate_terraform

def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    for cmd in ["validate","explain"]:
        x = sub.add_parser(cmd); x.add_argument("definition")
    g = sub.add_parser("generate"); g.add_argument("definition"); g.add_argument("--output", required=True)
    t = sub.add_parser("terraform-validate"); t.add_argument("path"); t.add_argument("--plan", action="store_true")
    a = p.parse_args()

    if a.cmd in ["validate","explain"]:
        d = parse(Path(a.definition).read_text())
        result = {"valid": True, "architecture": architecture(d)}
        if a.cmd == "explain":
            result["decisions"] = [
                "Source -> TEMP -> SOR via Glue",
                "Kafka uses Lambda Sink before TEMP",
                "SOT is processed by Glue",
                "SPEC uses Step Functions to orchestrate Glue",
                "Glue Catalog is used for governed datasets"
            ]
    elif a.cmd == "generate":
        result = generate(Path(a.definition).read_text(), a.output, Path(__file__).resolve().parent)
    else:
        result = validate_terraform(a.path, a.plan)

    print(json.dumps(result, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
