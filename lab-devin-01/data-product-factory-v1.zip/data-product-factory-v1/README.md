# Data Product Factory V1

Estrutura para uso com Devin baseada em Data Mesh.

Fluxo:
Devin -> Skill -> MCP -> Rules/Policies -> Terraform Templates -> artefatos -> validação -> Git/PR

Arquiteturas suportadas:
1. SQL table -> TEMP -> SOR
2. Kafka topic -> Lambda Sink -> TEMP -> SOR
3. SOR -> Glue -> SOT
4. SOT -> Step Functions -> Glue -> SPEC

AWS:
- S3
- AWS Glue Jobs
- Glue Data Catalog
- Lambda Sink
- Step Functions
- IAM

REGRA ABSOLUTA:
A Skill/MCP não executa terraform apply, terraform destroy ou terraform import.
Pode executar terraform fmt, terraform validate e, opcionalmente, terraform plan.
Deployment fica fora da Skill.
