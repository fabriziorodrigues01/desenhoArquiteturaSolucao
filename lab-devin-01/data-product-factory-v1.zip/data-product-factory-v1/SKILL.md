# Data Product Pipeline Factory Skill

## Objetivo
Interpretar uma definição declarativa de Data Product e gerar os artefatos padronizados de uma pipeline AWS para Data Mesh.

## Entrada
O desenvolvedor pode fornecer:
- tabela + colunas;
- SQL CREATE TABLE;
- tópico Kafka + schema;
- escolha de SOR;
- escolha de SOT;
- escolha de SPEC;
- regras de transformação.

## Decisão

SQL:
SOURCE -> S3 TEMP -> Glue -> SOR -> Glue Catalog

Kafka:
KAFKA -> Lambda Sink -> S3 TEMP -> Glue -> SOR -> Glue Catalog

SOT:
SOR -> Glue Job -> SOT -> Glue Catalog

SPEC:
SOT -> Step Functions -> Glue Validation/Transformation/Rules -> SPEC -> Glue Catalog

## Regras
- SOR é obrigatório nesta V1.
- SOT é derivado de SOR.
- SPEC exige SOT.
- Step Functions é somente orquestração.
- Glue executa processamento.
- Glue Catalog registra datasets governados.
- Infraestrutura deve vir dos templates Terraform oficiais.
- Não inventar recursos fora dos templates/policies.
- Não gerar credenciais ou secrets hard-coded.

## Saída
Gerar somente os arquivos necessários:
terraform/, glue/, lambda/, step-functions/, data-product.yaml/json e README.md.

## Terraform
PERMITIDO:
terraform fmt
terraform validate
terraform plan

PROIBIDO:
terraform apply
terraform destroy
terraform import

A Skill nunca faz deployment.
